const productsHigh = [
  {brand:'Rolex', name:'Submariner', img:'rolex_sub.jpg'},
  {brand:'Omega', name:'Speedmaster', img:'omega_speed.jpg'},
  {brand:'Tag Heuer', name:'Carrera', img:'tag_carrera.jpg'},
  {brand:'IWC', name:'Portugieser', img:'iwc_portugieser.jpg'},
  {brand:'Grand Seiko', name:'Heritage', img:'gs_heritage.jpg'}
];

const productsBudget = [
  {brand:'Casio', name:'F91W', img:'casio_f91w.jpg'},
  {brand:'Citizen', name:'Eco-Drive', img:'citizen_eco.jpg'},
  {brand:'G-Shock', name:'DW5600', img:'gshock_dw5600.jpg'}
];

function filter(brand) {
  const path = window.location.pathname;
  const isHigh = path.includes('highend');
  const data = isHigh ? productsHigh : productsBudget;
  const filtered = data.filter(p => p.brand === brand);
  renderProducts(filtered);
}

function renderProducts(list) {
  const cont = document.getElementById('product-list');
  if (!cont) return;
  cont.innerHTML = list.map(p => `
    <div class="item">
      <img src="assets/img/${p.img}" alt="${p.name}">
      <div>${p.name}</div>
    </div>
  `).join('');
}

window.onload = () => {
  const path = window.location.pathname;
  if (path.includes('highend')) filter('Rolex');
  if (path.includes('budget')) filter('Casio');
};
